jQuery(document).ready(function($){
  $('.counter').counterUp({
delay: 10,
time: 1000
});
});

// navtabs

  var firstTabEl = document.querySelector('#myTab li:last-child a')
  var firstTab = new bootstrap.Tab(firstTabEl)

  firstTab.show()

  // owl carosel










